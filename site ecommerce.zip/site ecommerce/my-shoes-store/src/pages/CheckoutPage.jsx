import React from 'react';
import { useCart } from '../context/CartContext';

const Checkout = () => {
  const { cart, dispatch } = useCart();

  const getTotalPrice = () =>
    cart.reduce((total, item) => total + item.price * item.quantity, 0);

  const finalizePurchase = async () => {
    try {
      // Implementar lógica para salvar pedido no backend
      console.log('Pedido finalizado:', cart);
      dispatch({ type: 'CLEAR_CART' });
      alert('Compra finalizada com sucesso!');
    } catch (error) {
      console.error('Erro ao finalizar compra:', error);
    }
  };

  return (
    <div>
      <h1>Checkout</h1>
      <div>
        {cart.map((item) => (
          <div key={item.id} style={{ marginBottom: '16px' }}>
            <h2>{item.name}</h2>
            <p>Quantidade: {item.quantity}</p>
            <p>Preço total: R${(item.price * item.quantity).toFixed(2)}</p>
            <button onClick={() => dispatch({ type: 'REMOVE_FROM_CART', payload: item })}>
              Remover
            </button>
          </div>
        ))}
      </div>
      <h2>Preço Total: R${getTotalPrice().toFixed(2)}</h2>
      <button onClick={finalizePurchase}>Finalizar Compra</button>
    </div>
  );
};

export default Checkout;
